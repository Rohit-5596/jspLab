package com.cg;

import java.util.ArrayList;
import java.util.List;

public class Employee {

	private String name;
	private int age;
	private String location;
	private String projectCode;
	private double salary;
	private List<String> skills;
	Department dept;
	
	
	public Employee(String name, int age, String location) {
		super();
		System.out.println("In second constructor");
		this.name = name;
		this.age = age;
		this.location = location;
		skills=new ArrayList<String>();
	}
	
	

	

	public Employee(String name, int age, String location, String projectCode, double salary, List<String> skills,
			Department dept) {
		super();
		this.name = name;
		this.age = age;
		this.location = location;
		this.projectCode = projectCode;
		this.salary = salary;
		this.skills = skills;
		this.dept = dept;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	public List<String> getSkills() {
		return skills;
	}

	public void setSkills(List<String> skills) {
		this.skills = skills;
	}

	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getProjectCode() {
		return projectCode;
	}
	public void setProjectCode(String projectCode) {
		this.projectCode = projectCode;
	}
	
	
	@Override
	public String toString() {
		return "Employee [name=" + name + ", age=" + age + ", location=" + location + ", projectCode=" + projectCode
				+ ", salary=" + salary + ", skills=" + skills + ", dept=" + dept + "]";
	}





	public Employee() {
		super();
		skills=new ArrayList<String>();
	}
	
	
}
