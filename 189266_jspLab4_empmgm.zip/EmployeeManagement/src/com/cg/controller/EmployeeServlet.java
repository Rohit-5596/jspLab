package com.cg.controller;
import java.util.*;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Employee;
import com.cg.service.EmployeeService;
import com.cg.service.EmployeeServiceImpl;
import com.sun.java_cup.internal.runtime.Scanner;

/**
 * Servlet implementation class EmployeeServlet
 */
@WebServlet("/EmployeeServlet")
public class EmployeeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	EmployeeService service;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeServlet() {
        super();
        service = new EmployeeServiceImpl();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(true);
		String qStr = request.getParameter("action");
		if("insert".equals(qStr))
		{
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("insert.jsp");
			dispatch.forward(request, response);
		}
		else if("displayById".equals(qStr))
		{
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("searchById.jsp");
			dispatch.forward(request, response);
			
			
		}
		
		else if("displayAll".equals(qStr))
		{
			ArrayList<Employee> list = 
					service.getAllEmployees();
			session.setAttribute("emplist", list);
			RequestDispatcher dispatch =
					request.getRequestDispatcher("searchAll.jsp");
			dispatch.forward(request, response);
			
		}
		else if("deleteEmp".equals(qStr))
		{
			String id=request.getParameter("id");
			int eId=Integer.parseInt(id);
			int d=service.DeleteEmployee(eId);
			if(d!=0){
				RequestDispatcher dispatch =
						request.getRequestDispatcher("delete.jsp");
				dispatch.forward(request, response);
			}
			}
		else if("updateEmp".equals(qStr))
		{
			String id=request.getParameter("id");
			int eId=Integer.parseInt(id);
			Employee emp=service.getEmployeeById(eId);
			session.setAttribute("emp", emp);
				RequestDispatcher dispatch =
						request.getRequestDispatcher("update.jsp");
				dispatch.forward(request, response);
			}
			
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession(false);
		String qStr = request.getParameter("action");
		if("insertEmp".equals(qStr))
		{
			String name = request.getParameter("eName");
			String addr = request.getParameter("addr");
		    String sal = request.getParameter("eSal");
		    int eSal = Integer.parseInt(sal);
		    Employee emp = new Employee();
		    emp.setEmpName(name);
		    emp.setEmpSal(eSal);
		    emp.setEmpAddr(addr);
		    Employee ref = service.addEmployee(emp);
		    if(ref!=null)
		    {
		    	session.setAttribute("emp", ref);
		    	RequestDispatcher dispatch =
		    			request.getRequestDispatcher("insertSuccess.jsp");
		    	dispatch.forward(request, response);
		    }
		}
		else if("searchById".equals(qStr))
		{
			System.out.println("in search by id");
			String empId = request.getParameter("id");
			int eId = Integer.parseInt(empId);
			Employee emp = service.getEmployeeById(eId);
			session.setAttribute("empById", emp);
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("success.jsp");
			dispatch.forward(request, response);
		}
		else if("updateEmp".equals(qStr))
		{
			String id=request.getParameter("eId");
			int eId=Integer.parseInt(id);
			String name=request.getParameter("eName");
			String sal=request.getParameter("eSal");
			int eSal=Integer.parseInt(sal);
			String addr=request.getParameter("eAddr");
			Employee emp=new Employee(eId,name,eSal,addr);
			service.update(emp);
			ArrayList<Employee> list=service.getAllEmployees();
			session.setAttribute("emplist", list);
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("searchAll.jsp");
			dispatch.forward(request, response);
		}

	}

}
