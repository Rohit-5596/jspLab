
package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.dto.*;
import com.cg.util.DBUtil;
import com.cg.util.MyStringDateUtil;

public class ConsumerDaoImpl implements ConsumersDao {

Connection con;
	
	public ConsumerDaoImpl()
	{
		con = DBUtil.getConnection();
		
	}
	@Override
	public ArrayList<Consumers> getAllConsumers() {
		
		String qry = "SELECT * FROM Consumers";
		ArrayList<Consumers>list = new ArrayList<Consumers>();
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			while(rs.next())
			{
				int num = rs.getInt(1);
				String name = rs.getString(2);
				String addr = rs.getString(3);
				Consumers consumers = new Consumers(num,name,addr);
				list.add(consumers);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public Consumers getConsumerById(int consumer_num) {
		Consumers ref = null;
		String qry = "SELECT * FROM Consumers WHERE consumer_num=?";
		try
		{
			PreparedStatement pstmt = 
					con.prepareStatement(qry);
			pstmt.setInt(1,consumer_num);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				int num = rs.getInt(1);
				String name = rs.getString(2);
				String addr = rs.getString(3);
				ref = new Consumers(num,name,addr);
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ref;
	}
	@Override
	public BillDetails getBillById(int consumer_num) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public BillDetails addBill(BillDetails bill) {
		
		BillDetails ref = null;
		
		
		
		String qry = "INSERT INTO BillDetails VALUES(seq_bill_num.nextval,?,?,?,?,sysdate)";
		try
		{
			PreparedStatement pstmt =  
					con.prepareStatement(qry);
			pstmt.setInt(1, bill.getConsumer_num());
			pstmt.setFloat(2, bill.getCur_reading());
			pstmt.setFloat(3, bill.getUnitConsumed());
			pstmt.setFloat(4, bill.getNetAmount());
			int row = pstmt.executeUpdate();
			if(row>0)
			{
				bill.setBill_num(getBillNum());
				ref = bill;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ref;
	}
	public int getBillNum()
	{
		int id = 0;
		String qry = "SELECT seq_bill_num.currval FROM DUAL";
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(qry);
			if(rs.next())
			{
				id = rs.getInt(1);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return id;
	}
	@Override
	public ArrayList<BillDetails> getAllBillDetailsById(int consumer_num) {
		
		String qry = "SELECT * FROM BillDetails where consumer_num=?";
		ArrayList<BillDetails>list = new ArrayList<BillDetails>();
		try
		{
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1,consumer_num );
			ResultSet rs = pstmt.executeQuery();
			while(rs.next())
			{
				int num = rs.getInt(1);
				float cur_reading = rs.getFloat(3);
				float unitConsumed = rs.getFloat(4);
				float netAmount = rs.getFloat(5);
				LocalDate lDate=MyStringDateUtil.fromSqlToLocalDate(rs.getDate(6));
				BillDetails bill = new BillDetails(num,consumer_num,cur_reading,unitConsumed,netAmount,lDate);
				list.add(bill);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return list;
	}
	}
