package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;

public interface ConsumersService {

	public BillDetails addBill(BillDetails bill);
	public ArrayList<Consumers> getAllConsumers();
	public Consumers getConsumerById(int consumer_num);
	public BillDetails getBillById(int consumer_num);
	public  ArrayList<BillDetails> getAllBillDetailsById(int consumer_num);
}
