package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.*;
import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;

public class ConsumerServiceImpl implements ConsumersService {

	ConsumersDao dao;

	public ConsumerServiceImpl()
	{
		dao=new ConsumerDaoImpl();
	}
	@Override
	public ArrayList<Consumers> getAllConsumers() {
		
		return dao.getAllConsumers();
	}

	@Override
	public Consumers getConsumerById(int consumer_num) {
		
		return dao.getConsumerById(consumer_num);
	}
	@Override
	public BillDetails getBillById(int consumer_num) {
		
		return dao.getBillById(consumer_num);
	}
	@Override
	public BillDetails addBill(BillDetails bill) {
		
		return dao.addBill(bill);
	}
	@Override
	public ArrayList<BillDetails> getAllBillDetailsById(int consumer_num) {
		
		return dao.getAllBillDetailsById(consumer_num);
	}

}
