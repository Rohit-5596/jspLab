package com.cg.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.*;
import com.cg.service.*;

/**
 * Servlet implementation class ConsumerServlet
 */
@WebServlet("/ConsumerServlet")
public class ConsumerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	ConsumersService service;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ConsumerServlet() {
        super();
        service = new ConsumerServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		String qStr = request.getParameter("action");
		if("displayById".equals(qStr))
		{
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("searchById.jsp");
			dispatch.forward(request, response);
			
			
		}
		
		else if("displayAll".equals(qStr))
		{
			ArrayList<Consumers> list = service.getAllConsumers();
			session.setAttribute("consumerlist", list);
			RequestDispatcher dispatch =
					request.getRequestDispatcher("searchAll.jsp");
			dispatch.forward(request, response);
			
		}
		else if("showBill".equals(qStr))
		{
			int consumer_num=Integer.parseInt(request.getParameter("id"));
			ArrayList<BillDetails> list=service.getAllBillDetailsById(consumer_num);
			session.setAttribute("billDetails", list);
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("showBillById.jsp");
			dispatch.forward(request, response);
			
		}
		else if("insertBillDetails".equals(qStr))
		{
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("insertBill.jsp");
			dispatch.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(false);
		String qStr = request.getParameter("action");
		if("searchById".equals(qStr))
		{
			System.out.println("search by consumer number");
			String num = request.getParameter("id");
			int consumer_num = Integer.parseInt(num);
			Consumers consumer = service.getConsumerById(consumer_num);
			session.setAttribute("consumerById", consumer);
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("success.jsp");
			dispatch.forward(request, response);
		}
		else if("showBillById".equals(qStr))
		{
			System.out.println("in search by id");
			String num = request.getParameter("id");
			int consumer_num = Integer.parseInt(num);
			BillDetails bill=service.getBillById(consumer_num);
			session.setAttribute("billDetails", bill);
			RequestDispatcher dispatch = 
					request.getRequestDispatcher("showBillById.jsp");
			dispatch.forward(request, response);
		}
		if("insertBill".equals(qStr))
		{
			String num = request.getParameter("cNo");
			int consumer_num = Integer.parseInt(num);
			String last = request.getParameter("lTh");
			float lTh = Float.parseFloat(last);
			String cur = request.getParameter("cTh");
			float cTh = Float.parseFloat(cur);
		    BillDetails bill = new BillDetails();
		    bill.setConsumer_num(consumer_num);
		    bill.setUnitConsumed(cTh-lTh);
		    bill.setCur_reading(cTh);
		    bill.setNetAmount((cTh-lTh)*1.15f+100);
		    BillDetails ref = service.addBill(bill);
		    if(ref!=null)
		    {
		    	session.setAttribute("billDetails", ref);
		    	RequestDispatcher dispatch =
		    			request.getRequestDispatcher("insertSuccess.jsp");
		    	dispatch.forward(request, response);
		    }
		}
	}

}
